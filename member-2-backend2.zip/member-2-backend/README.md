# Member 2 - Backend

Assigned to: Backend Developer

Stack: Spring Boot 3, Java 17, MySQL (H2 for local preview)

## Your work

- User authentication (email sign up and login, JWT)
- All REST APIs used by the React app
- Database connection and entity mapping
- Proxy AI requests to Member 3 (`http://localhost:5000`)

## API map

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/api/auth/signup` | Create account |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Current user |
| GET/PUT | `/api/settings` | Theme, wallpaper, revision mode |
| POST | `/api/summaries` | Save / generate summary |
| GET | `/api/summaries` | List summaries |
| POST | `/api/quizzes` | Generate quiz |
| GET | `/api/quizzes` | List quizzes |
| POST | `/api/quizzes/{id}/attempt` | Submit answers |
| GET | `/api/quizzes/{id}/results` | Results with time and attempts |
| POST | `/api/flashcards` | Generate flash cards |
| POST | `/api/bullets` | Paragraph to bullets |
| POST | `/api/maths` | Maths to diagram |
| GET/POST | `/api/reminders` | Daily reminder alarms |
| GET | `/api/reports/weekly` | Weekly report |
| GET | `/api/reports/monthly` | Monthly report |
| GET/POST | `/api/tasks` | Daily tasks and reward points |
| GET | `/api/history` | User history |

## Database

Local preview uses H2 so the app starts without installing MySQL.

To use MySQL:

1. Create database `studynest`
2. Run `src/main/resources/schema-mysql.sql`
3. Start with `--spring.profiles.active=mysql`

## Run

```bash
mvn spring-boot:run
```
