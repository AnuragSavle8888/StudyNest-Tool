package com.studyforge.flashcard;

import com.studyforge.ai.AiClient;
import com.studyforge.auth.AuthUser;
import com.studyforge.history.HistoryService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class ToolController {
    private final AiClient aiClient;
    private final HistoryService historyService;

    public ToolController(AiClient aiClient, HistoryService historyService) {
        this.aiClient = aiClient;
        this.historyService = historyService;
    }

    @PostMapping("/flashcards")
    public Map<String, Object> flashcards(@AuthenticationPrincipal AuthUser user, @RequestBody Map<String, Object> body) {
        Map<String, Object> result = aiClient.post("/ai/flashcards", Map.of("text", body.getOrDefault("sourceText", "")));
        historyService.record(user.getId(), "flashcards", "Generated flash cards");
        return result;
    }

    @PostMapping("/bullets")
    public Map<String, Object> bullets(@AuthenticationPrincipal AuthUser user, @RequestBody Map<String, Object> body) {
        Map<String, Object> result = aiClient.post("/ai/bullets", Map.of("text", body.getOrDefault("sourceText", "")));
        historyService.record(user.getId(), "bullets", "Converted paragraph to bullets");
        return result;
    }

    @PostMapping("/maths")
    public Map<String, Object> maths(@AuthenticationPrincipal AuthUser user, @RequestBody Map<String, Object> body) {
        Map<String, Object> result = aiClient.post("/ai/maths", Map.of(
                "text", body.getOrDefault("sourceText", ""),
                "kind", body.getOrDefault("kind", "geometry")
        ));
        historyService.record(user.getId(), "maths", "Created maths diagram");
        return result;
    }
}
