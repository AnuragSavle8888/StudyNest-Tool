package com.studyforge.history;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HistoryService {
    private final HistoryEventRepository repository;

    public HistoryService(HistoryEventRepository repository) {
        this.repository = repository;
    }

    public void record(Long userId, String action, String detail) {
        HistoryEvent event = new HistoryEvent();
        event.setUserId(userId);
        event.setAction(action);
        event.setDetail(detail);
        repository.save(event);
    }

    public List<HistoryEvent> list(Long userId) {
        return repository.findByUserIdOrderByCreatedAtDesc(userId);
    }
}
