package com.studyforge.history;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface HistoryEventRepository extends JpaRepository<HistoryEvent, Long> {
    List<HistoryEvent> findByUserIdOrderByCreatedAtDesc(Long userId);
    long countByUserIdAndActionAndCreatedAtAfter(Long userId, String action, java.time.Instant after);
}
