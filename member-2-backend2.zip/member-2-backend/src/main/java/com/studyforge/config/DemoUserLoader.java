package com.studyforge.config;

import com.studyforge.auth.AuthDtos;
import com.studyforge.auth.AuthService;
import com.studyforge.user.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DemoUserLoader implements CommandLineRunner {
    private final UserRepository userRepository;
    private final AuthService authService;

    public DemoUserLoader(UserRepository userRepository, AuthService authService) {
        this.userRepository = userRepository;
        this.authService = authService;
    }

    @Override
    public void run(String... args) {
        if (userRepository.existsByEmail("demo@studynest.app")) {
            return;
        }
        AuthDtos.SignupRequest request = new AuthDtos.SignupRequest();
        request.fullName = "Asha Patel";
        request.email = "demo@studynest.app";
        request.password = "StudyNest123";
        authService.signup(request);
    }
}
