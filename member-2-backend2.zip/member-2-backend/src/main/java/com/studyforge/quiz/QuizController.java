package com.studyforge.quiz;

import com.studyforge.ai.AiClient;
import com.studyforge.auth.AuthUser;
import com.studyforge.common.ApiException;
import com.studyforge.history.HistoryService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/quizzes")
public class QuizController {
    private final QuizRepository quizRepository;
    private final QuizAttemptRepository attemptRepository;
    private final AiClient aiClient;
    private final HistoryService historyService;

    public QuizController(
            QuizRepository quizRepository,
            QuizAttemptRepository attemptRepository,
            AiClient aiClient,
            HistoryService historyService
    ) {
        this.quizRepository = quizRepository;
        this.attemptRepository = attemptRepository;
        this.aiClient = aiClient;
        this.historyService = historyService;
    }

    @GetMapping
    public List<Quiz> list(@AuthenticationPrincipal AuthUser user) {
        return quizRepository.findByUserIdOrderByCreatedAtDesc(user.getId());
    }

    @GetMapping("/{id}")
    public Quiz get(@AuthenticationPrincipal AuthUser user, @PathVariable Long id) {
        return findOwned(user.getId(), id);
    }

    @PostMapping
    @SuppressWarnings("unchecked")
    public Quiz create(@AuthenticationPrincipal AuthUser user, @RequestBody Map<String, Object> body) {
        String source = String.valueOf(body.getOrDefault("sourceText", ""));
        int count = 10;
        try {
            count = Integer.parseInt(String.valueOf(body.getOrDefault("questionCount", 10)));
        } catch (NumberFormatException ignored) {
        }
        if (count < 1 || count > 20) throw new ApiException(400, "Question count must be between 1 and 20");
        if (source.isBlank()) throw new ApiException(400, "Study text is required");
        Map<String, Object> ai = aiClient.post("/ai/quiz", Map.of("text", source, "count", count));
        Quiz quiz = new Quiz();
        quiz.setUserId(user.getId());
        quiz.setTitle(String.valueOf(ai.getOrDefault("title", "Practice quiz")));
        quiz.setSourceText(source);
        List<Map<String, Object>> questions = (List<Map<String, Object>>) ai.getOrDefault("questions", List.of());
        for (Map<String, Object> item : questions) {
            QuizQuestion question = new QuizQuestion();
            question.setQuiz(quiz);
            question.setPrompt(String.valueOf(item.getOrDefault("prompt", "")));
            question.setOptionA(String.valueOf(item.getOrDefault("A", item.getOrDefault("optionA", ""))));
            question.setOptionB(String.valueOf(item.getOrDefault("B", item.getOrDefault("optionB", ""))));
            question.setOptionC(String.valueOf(item.getOrDefault("C", item.getOrDefault("optionC", ""))));
            question.setOptionD(String.valueOf(item.getOrDefault("D", item.getOrDefault("optionD", ""))));
            question.setCorrectOption(String.valueOf(item.getOrDefault("answer", "A")));
            quiz.getQuestions().add(question);
        }
        quiz.setQuestionCount(quiz.getQuestions().size());
        quizRepository.save(quiz);
        historyService.record(user.getId(), "quiz", "Generated quiz with " + quiz.getQuestionCount() + " questions");
        return quiz;
    }

    @PostMapping("/{id}/attempt")
    public QuizAttempt attempt(
            @AuthenticationPrincipal AuthUser user,
            @PathVariable Long id,
            @RequestBody Map<String, Object> body
    ) {
        Quiz quiz = findOwned(user.getId(), id);
        Map<?, ?> answers = body.get("answers") instanceof Map<?, ?> map ? map : Map.of();
        int score = 0;
        for (QuizQuestion question : quiz.getQuestions()) {
            Object chosen = answers.get(String.valueOf(question.getId()));
            if (chosen != null && String.valueOf(chosen).equalsIgnoreCase(question.getCorrectOption())) {
                score++;
            }
        }
        int duration = 1;
        try {
            duration = Integer.parseInt(String.valueOf(body.getOrDefault("durationSeconds", 1)));
        } catch (NumberFormatException ignored) {
        }
        QuizAttempt attempt = new QuizAttempt();
        attempt.setQuizId(quiz.getId());
        attempt.setUserId(user.getId());
        attempt.setScore(score);
        attempt.setTotal(quiz.getQuestions().size());
        attempt.setDurationSeconds(Math.max(1, duration));
        attemptRepository.save(attempt);
        historyService.record(user.getId(), "quiz-attempt", "Scored " + score + "/" + attempt.getTotal());
        return attempt;
    }

    @GetMapping("/{id}/results")
    public Map<String, Object> results(@AuthenticationPrincipal AuthUser user, @PathVariable Long id) {
        findOwned(user.getId(), id);
        List<QuizAttempt> attempts = attemptRepository.findByQuizIdAndUserIdOrderByCreatedAtDesc(id, user.getId());
        return Map.of(
                "attemptCount", attemptRepository.countByQuizIdAndUserId(id, user.getId()),
                "attempts", attempts
        );
    }

    private Quiz findOwned(Long userId, Long id) {
        Quiz quiz = quizRepository.findById(id).orElseThrow(() -> new ApiException(404, "Quiz not found"));
        if (!quiz.getUserId().equals(userId)) throw new ApiException(404, "Quiz not found");
        return quiz;
    }
}
