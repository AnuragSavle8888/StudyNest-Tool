package com.studyforge.task;

import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;

public interface StudyTaskRepository extends JpaRepository<StudyTask, Long> {
    List<StudyTask> findByUserIdOrderByCreatedAtAsc(Long userId);
    long countByUserIdAndCompletedAndCompletedAtAfter(Long userId, boolean completed, Instant after);
}
