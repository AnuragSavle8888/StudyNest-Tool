package com.studyforge.task;

import com.studyforge.auth.AuthUser;
import com.studyforge.common.ApiException;
import com.studyforge.history.HistoryService;
import com.studyforge.user.User;
import com.studyforge.user.UserRepository;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    private final StudyTaskRepository taskRepository;
    private final UserRepository userRepository;
    private final HistoryService historyService;

    public TaskController(StudyTaskRepository taskRepository, UserRepository userRepository, HistoryService historyService) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
        this.historyService = historyService;
    }

    @GetMapping
    public Map<String, Object> list(@AuthenticationPrincipal AuthUser authUser) {
        User user = userRepository.findById(authUser.getId()).orElseThrow();
        List<StudyTask> tasks = taskRepository.findByUserIdOrderByCreatedAtAsc(user.getId());
        return Map.of("points", user.getPoints(), "tasks", tasks);
    }

    @PostMapping("/{id}/complete")
    public Map<String, Object> complete(@AuthenticationPrincipal AuthUser authUser, @PathVariable Long id) {
        StudyTask task = taskRepository.findById(id).orElseThrow(() -> new ApiException(404, "Task not found"));
        if (!task.getUserId().equals(authUser.getId())) throw new ApiException(404, "Task not found");
        if (!task.isCompleted()) {
            task.setCompleted(true);
            task.setCompletedAt(Instant.now());
            taskRepository.save(task);
            User user = userRepository.findById(authUser.getId()).orElseThrow();
            user.setPoints(user.getPoints() + task.getPoints());
            userRepository.save(user);
            historyService.record(user.getId(), "reward", "Completed " + task.getTitle() + " (+" + task.getPoints() + ")");
        }
        return list(authUser);
    }
}
