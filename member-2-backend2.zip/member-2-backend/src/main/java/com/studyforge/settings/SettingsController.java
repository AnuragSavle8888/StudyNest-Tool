package com.studyforge.settings;

import com.studyforge.auth.AuthUser;
import com.studyforge.history.HistoryService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/settings")
public class SettingsController {
    private final UserSettingsRepository repository;
    private final HistoryService historyService;

    public SettingsController(UserSettingsRepository repository, HistoryService historyService) {
        this.repository = repository;
        this.historyService = historyService;
    }

    @GetMapping
    public Map<String, Object> get(@AuthenticationPrincipal AuthUser user) {
        UserSettings settings = repository.findByUserId(user.getId()).orElseGet(() -> create(user.getId()));
        return toMap(settings);
    }

    @PutMapping
    public Map<String, Object> save(@AuthenticationPrincipal AuthUser user, @RequestBody Map<String, Object> body) {
        UserSettings settings = repository.findByUserId(user.getId()).orElseGet(() -> create(user.getId()));
        if (body.get("theme") != null) settings.setTheme(String.valueOf(body.get("theme")));
        if (body.get("revisionMode") != null) settings.setRevisionMode(Boolean.parseBoolean(String.valueOf(body.get("revisionMode"))));
        if (body.get("wallpaper") != null) settings.setWallpaper(String.valueOf(body.get("wallpaper")));
        if (body.containsKey("wallpaperPhoto")) settings.setWallpaperPhoto(String.valueOf(body.get("wallpaperPhoto")));
        repository.save(settings);
        historyService.record(user.getId(), "settings", "Updated theme or wallpaper");
        return toMap(settings);
    }

    private UserSettings create(Long userId) {
        UserSettings settings = new UserSettings();
        settings.setUserId(userId);
        return repository.save(settings);
    }

    private Map<String, Object> toMap(UserSettings settings) {
        return Map.of(
                "theme", settings.getTheme(),
                "revisionMode", settings.isRevisionMode(),
                "wallpaper", settings.getWallpaper(),
                "wallpaperPhoto", settings.getWallpaperPhoto() == null ? "" : settings.getWallpaperPhoto()
        );
    }
}
