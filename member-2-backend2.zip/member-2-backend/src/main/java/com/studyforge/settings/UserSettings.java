package com.studyforge.settings;

import jakarta.persistence.*;

@Entity
@Table(name = "user_settings")
public class UserSettings {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private String theme = "light";
    private boolean revisionMode = false;
    private String wallpaper = "aurora";
    @Lob
    private String wallpaperPhoto = "";

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getTheme() { return theme; }
    public void setTheme(String theme) { this.theme = theme; }
    public boolean isRevisionMode() { return revisionMode; }
    public void setRevisionMode(boolean revisionMode) { this.revisionMode = revisionMode; }
    public String getWallpaper() { return wallpaper; }
    public void setWallpaper(String wallpaper) { this.wallpaper = wallpaper; }
    public String getWallpaperPhoto() { return wallpaperPhoto; }
    public void setWallpaperPhoto(String wallpaperPhoto) { this.wallpaperPhoto = wallpaperPhoto; }
}
