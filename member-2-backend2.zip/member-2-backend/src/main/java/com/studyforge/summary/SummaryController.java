package com.studyforge.summary;

import com.studyforge.ai.AiClient;
import com.studyforge.auth.AuthUser;
import com.studyforge.common.ApiException;
import com.studyforge.history.HistoryService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/summaries")
public class SummaryController {
    private static final int WORD_LIMIT = 500;
    private final SummaryRepository repository;
    private final AiClient aiClient;
    private final HistoryService historyService;
    private final FileTextExtractor extractor;

    public SummaryController(
            SummaryRepository repository,
            AiClient aiClient,
            HistoryService historyService,
            FileTextExtractor extractor
    ) {
        this.repository = repository;
        this.aiClient = aiClient;
        this.historyService = historyService;
        this.extractor = extractor;
    }

    @GetMapping
    public List<Summary> list(@AuthenticationPrincipal AuthUser user) {
        return repository.findByUserIdOrderByCreatedAtDesc(user.getId());
    }

    @PostMapping
    public Summary create(@AuthenticationPrincipal AuthUser user, @RequestBody Map<String, String> body) {
        return saveSummary(user.getId(), body.getOrDefault("title", "Summary"), body.getOrDefault("content", ""));
    }

    @PostMapping("/upload")
    public Summary upload(
            @AuthenticationPrincipal AuthUser user,
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "title", required = false) String title
    ) {
        String text = extractor.extract(file);
        return saveSummary(user.getId(), title == null || title.isBlank() ? file.getOriginalFilename() : title, text);
    }

    private Summary saveSummary(Long userId, String title, String content) {
        int words = content.trim().isEmpty() ? 0 : content.trim().split("\\s+").length;
        if (words == 0) throw new ApiException(400, "Notes are empty");
        if (words > WORD_LIMIT) throw new ApiException(400, "Keep notes under 500 words");
        Map<String, Object> ai = aiClient.post("/ai/summarise", Map.of("text", content, "limit", WORD_LIMIT));
        Summary summary = new Summary();
        summary.setUserId(userId);
        summary.setTitle(title);
        summary.setSourceText(content);
        summary.setSummaryText(String.valueOf(ai.getOrDefault("summary", "")));
        repository.save(summary);
        historyService.record(userId, "summary", "Generated summary: " + title);
        return summary;
    }
}
