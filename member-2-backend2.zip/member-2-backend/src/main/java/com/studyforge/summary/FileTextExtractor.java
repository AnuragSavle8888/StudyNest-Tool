package com.studyforge.summary;

import com.studyforge.common.ApiException;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Component
public class FileTextExtractor {
    public String extract(MultipartFile file) {
        String name = file.getOriginalFilename() == null ? "" : file.getOriginalFilename().toLowerCase();
        try {
            byte[] bytes = file.getBytes();
            if (name.endsWith(".txt") || (file.getContentType() != null && file.getContentType().contains("text"))) {
                return new String(bytes, StandardCharsets.UTF_8);
            }
            if (name.endsWith(".zip")) {
                return extractZip(bytes);
            }
            if (name.endsWith(".pdf")) {
                return extractPdf(bytes);
            }
            throw new ApiException(400, "Supported files: PDF, TXT, ZIP");
        } catch (ApiException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ApiException(400, "Could not read uploaded file");
        }
    }

    private String extractZip(byte[] bytes) throws IOException {
        StringBuilder builder = new StringBuilder();
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (entry.isDirectory()) continue;
                String entryName = entry.getName().toLowerCase();
                byte[] content = zip.readAllBytes();
                if (entryName.endsWith(".txt")) {
                    builder.append(new String(content, StandardCharsets.UTF_8)).append('\n');
                } else if (entryName.endsWith(".pdf")) {
                    builder.append(extractPdf(content)).append('\n');
                }
            }
        }
        if (builder.isEmpty()) {
            throw new ApiException(400, "ZIP must contain TXT or PDF files");
        }
        return builder.toString();
    }

    private String extractPdf(byte[] bytes) {
        String raw = new String(bytes, StandardCharsets.ISO_8859_1);
        StringBuilder text = new StringBuilder();
        int index = 0;
        while (index < raw.length()) {
            int start = raw.indexOf("BT", index);
            if (start < 0) break;
            int end = raw.indexOf("ET", start);
            if (end < 0) break;
            String block = raw.substring(start, end);
            int cursor = 0;
            while (true) {
                int open = block.indexOf('(', cursor);
                if (open < 0) break;
                int close = block.indexOf(')', open + 1);
                if (close < 0) break;
                text.append(block, open + 1, close).append(' ');
                cursor = close + 1;
            }
            index = end + 2;
        }
        String extracted = text.toString().replaceAll("\\\\n", " ").replaceAll("\\s+", " ").trim();
        if (extracted.isBlank()) {
            throw new ApiException(400, "Could not extract text from PDF. Try a TXT file.");
        }
        return extracted;
    }
}
