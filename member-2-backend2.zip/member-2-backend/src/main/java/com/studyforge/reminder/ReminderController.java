package com.studyforge.reminder;

import com.studyforge.auth.AuthUser;
import com.studyforge.common.ApiException;
import com.studyforge.history.HistoryService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reminders")
public class ReminderController {
    private final ReminderRepository repository;
    private final HistoryService historyService;

    public ReminderController(ReminderRepository repository, HistoryService historyService) {
        this.repository = repository;
        this.historyService = historyService;
    }

    @GetMapping
    public List<Reminder> list(@AuthenticationPrincipal AuthUser user) {
        return repository.findByUserIdOrderByCreatedAtDesc(user.getId());
    }

    @PostMapping
    public Reminder create(@AuthenticationPrincipal AuthUser user, @RequestBody Map<String, Object> body) {
        Reminder reminder = new Reminder();
        reminder.setUserId(user.getId());
        reminder.setTitle(String.valueOf(body.getOrDefault("title", "Study reminder")));
        reminder.setTime(String.valueOf(body.getOrDefault("time", "19:00")));
        try {
            reminder.setSeconds(Integer.parseInt(String.valueOf(body.getOrDefault("seconds", 1500))));
        } catch (NumberFormatException ignored) {
            reminder.setSeconds(1500);
        }
        repository.save(reminder);
        historyService.record(user.getId(), "reminder", "Set reminder " + reminder.getTitle());
        return reminder;
    }

    @PostMapping("/{id}/toggle")
    public Reminder toggle(@AuthenticationPrincipal AuthUser user, @PathVariable Long id) {
        Reminder reminder = repository.findById(id).orElseThrow(() -> new ApiException(404, "Reminder not found"));
        if (!reminder.getUserId().equals(user.getId())) throw new ApiException(404, "Reminder not found");
        reminder.setEnabled(!reminder.isEnabled());
        return repository.save(reminder);
    }
}
