package com.studyforge.report;

import com.studyforge.auth.AuthUser;
import com.studyforge.history.HistoryEventRepository;
import com.studyforge.quiz.QuizRepository;
import com.studyforge.summary.SummaryRepository;
import com.studyforge.task.StudyTaskRepository;
import com.studyforge.user.UserRepository;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
    private final SummaryRepository summaryRepository;
    private final QuizRepository quizRepository;
    private final StudyTaskRepository taskRepository;
    private final HistoryEventRepository historyEventRepository;
    private final UserRepository userRepository;

    public ReportController(
            SummaryRepository summaryRepository,
            QuizRepository quizRepository,
            StudyTaskRepository taskRepository,
            HistoryEventRepository historyEventRepository,
            UserRepository userRepository
    ) {
        this.summaryRepository = summaryRepository;
        this.quizRepository = quizRepository;
        this.taskRepository = taskRepository;
        this.historyEventRepository = historyEventRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/weekly")
    public Map<String, Object> weekly(@AuthenticationPrincipal AuthUser user) {
        return report(user.getId(), Instant.now().minus(7, ChronoUnit.DAYS));
    }

    @GetMapping("/monthly")
    public Map<String, Object> monthly(@AuthenticationPrincipal AuthUser user) {
        return report(user.getId(), Instant.now().minus(30, ChronoUnit.DAYS));
    }

    private Map<String, Object> report(Long userId, Instant after) {
        int points = userRepository.findById(userId).map(u -> u.getPoints()).orElse(0);
        return Map.of(
                "summaries", summaryRepository.countByUserIdAndCreatedAtAfter(userId, after),
                "quizzes", quizRepository.countByUserIdAndCreatedAtAfter(userId, after),
                "tasksCompleted", taskRepository.countByUserIdAndCompletedAndCompletedAtAfter(userId, true, after),
                "points", points,
                "historyEvents", historyEventRepository.countByUserIdAndActionAndCreatedAtAfter(userId, "login", after)
        );
    }
}
