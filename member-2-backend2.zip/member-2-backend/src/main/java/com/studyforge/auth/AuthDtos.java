package com.studyforge.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class AuthDtos {
    public static class SignupRequest {
        @NotBlank public String fullName;
        @Email @NotBlank public String email;
        @Size(min = 6) public String password;
    }

    public static class LoginRequest {
        @Email @NotBlank public String email;
        @NotBlank public String password;
    }

    public static class AuthResponse {
        public String token;
        public Long id;
        public String fullName;
        public String email;
    }

    public static class MeResponse {
        public Long id;
        public String fullName;
        public String email;
        public int points;
    }
}
