package com.studyforge.auth;

import com.studyforge.common.ApiException;
import com.studyforge.history.HistoryService;
import com.studyforge.settings.UserSettings;
import com.studyforge.settings.UserSettingsRepository;
import com.studyforge.task.StudyTask;
import com.studyforge.task.StudyTaskRepository;
import com.studyforge.user.User;
import com.studyforge.user.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final UserSettingsRepository settingsRepository;
    private final StudyTaskRepository taskRepository;
    private final HistoryService historyService;

    public AuthService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService,
            UserSettingsRepository settingsRepository,
            StudyTaskRepository taskRepository,
            HistoryService historyService
    ) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.settingsRepository = settingsRepository;
        this.taskRepository = taskRepository;
        this.historyService = historyService;
    }

    @Transactional
    public AuthDtos.AuthResponse signup(AuthDtos.SignupRequest request) {
        if (userRepository.existsByEmail(request.email.toLowerCase())) {
            throw new ApiException(409, "Email already registered");
        }
        User user = new User();
        user.setFullName(request.fullName);
        user.setEmail(request.email.toLowerCase());
        user.setPasswordHash(passwordEncoder.encode(request.password));
        user = userRepository.save(user);
        seedAccount(user);
        historyService.record(user.getId(), "signup", "Created StudyNest account");
        return toAuth(user);
    }

    public AuthDtos.AuthResponse login(AuthDtos.LoginRequest request) {
        User user = userRepository.findByEmail(request.email.toLowerCase())
                .orElseThrow(() -> new ApiException(401, "Invalid email or password"));
        if (!passwordEncoder.matches(request.password, user.getPasswordHash())) {
            throw new ApiException(401, "Invalid email or password");
        }
        historyService.record(user.getId(), "login", "Logged in");
        return toAuth(user);
    }

    public AuthDtos.MeResponse me(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new ApiException(404, "User not found"));
        AuthDtos.MeResponse response = new AuthDtos.MeResponse();
        response.id = user.getId();
        response.fullName = user.getFullName();
        response.email = user.getEmail();
        response.points = user.getPoints();
        return response;
    }

    private AuthDtos.AuthResponse toAuth(User user) {
        AuthDtos.AuthResponse response = new AuthDtos.AuthResponse();
        response.token = jwtService.create(user.getId(), user.getEmail());
        response.id = user.getId();
        response.fullName = user.getFullName();
        response.email = user.getEmail();
        return response;
    }

    private void seedAccount(User user) {
        UserSettings settings = new UserSettings();
        settings.setUserId(user.getId());
        settingsRepository.save(settings);
        createTask(user.getId(), "Summarise one lecture", 10);
        createTask(user.getId(), "Attempt a 10-question quiz", 20);
        createTask(user.getId(), "Review 5 flash cards", 15);
        createTask(user.getId(), "Set a daily reminder", 5);
    }

    private void createTask(Long userId, String title, int points) {
        StudyTask task = new StudyTask();
        task.setUserId(userId);
        task.setTitle(title);
        task.setPoints(points);
        taskRepository.save(task);
    }
}
