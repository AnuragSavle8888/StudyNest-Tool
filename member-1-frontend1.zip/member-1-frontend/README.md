# Member 1 - Frontend

Assigned to: Frontend Developer

Stack: React, HTML, CSS, JavaScript, Vite

## Your pages

| Route | Screen |
| --- | --- |
| `/login` | Email login |
| `/signup` | Email sign up |
| `/` | Dashboard with student name and wallpaper |
| `/summariser` | 500-word summariser, PDF / TXT / ZIP |
| `/quiz` | Quiz generator (up to 20 MCQs) |
| `/quiz/:id` | Attempt quiz |
| `/quiz/:id/result` | Time taken and attempts |
| `/flashcards` | Flash card generator |
| `/bullets` | Paragraph to bullets |
| `/maths` | Maths text to algebra / geometry diagrams |
| `/reminders` | Daily reminder timer alarm |
| `/reports` | Weekly and monthly reports |
| `/rewards` | Daily task points |
| `/history` | User history |
| `/settings` | Revision mode, theme, wallpaper |

## Run

```bash
npm install
npm run dev
```

API calls go to `/api` and are proxied to Spring Boot on port 8080.
