import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './auth.jsx'
import Layout from './components/Layout.jsx'
import Login from './pages/Login.jsx'
import Signup from './pages/Signup.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Summariser from './pages/Summariser.jsx'
import Quiz from './pages/Quiz.jsx'
import QuizAttempt from './pages/QuizAttempt.jsx'
import QuizResult from './pages/QuizResult.jsx'
import Flashcards from './pages/Flashcards.jsx'
import Bullets from './pages/Bullets.jsx'
import Maths from './pages/Maths.jsx'
import Reminders from './pages/Reminders.jsx'
import Reports from './pages/Reports.jsx'
import Rewards from './pages/Rewards.jsx'
import History from './pages/History.jsx'
import Settings from './pages/Settings.jsx'

function Guard({ children }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="auth-wrap">Loading StudyNest...</div>
  if (!user) return <Navigate to="/login" replace />
  return children
}

function Guest({ children }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="auth-wrap">Loading StudyNest...</div>
  if (user) return <Navigate to="/" replace />
  return children
}

export default function App() {
  return (
    <Routes>
      <Route
        path="/login"
        element={
          <Guest>
            <Login />
          </Guest>
        }
      />
      <Route
        path="/signup"
        element={
          <Guest>
            <Signup />
          </Guest>
        }
      />
      <Route
        element={
          <Guard>
            <Layout />
          </Guard>
        }
      >
        <Route path="/" element={<Dashboard />} />
        <Route path="/summariser" element={<Summariser />} />
        <Route path="/quiz" element={<Quiz />} />
        <Route path="/quiz/:id" element={<QuizAttempt />} />
        <Route path="/quiz/:id/result" element={<QuizResult />} />
        <Route path="/flashcards" element={<Flashcards />} />
        <Route path="/bullets" element={<Bullets />} />
        <Route path="/maths" element={<Maths />} />
        <Route path="/reminders" element={<Reminders />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/rewards" element={<Rewards />} />
        <Route path="/history" element={<History />} />
        <Route path="/settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
