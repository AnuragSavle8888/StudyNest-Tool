import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../auth.jsx'

const links = [
  { to: '/', label: 'Home', icon: 'H' },
  { to: '/summariser', label: 'Summariser', icon: 'S' },
  { to: '/quiz', label: 'Quiz generator', icon: 'Q' },
  { to: '/flashcards', label: 'Flash cards', icon: 'F' },
  { to: '/bullets', label: 'Bullet points', icon: 'B' },
  { to: '/maths', label: 'Maths diagrams', icon: 'M' },
  { to: '/reminders', label: 'Daily reminder', icon: 'R' },
  { to: '/reports', label: 'Weekly / monthly', icon: 'P' },
  { to: '/rewards', label: 'Task rewards', icon: '*' },
  { to: '/history', label: 'History', icon: 'Y' },
  { to: '/settings', label: 'Settings', icon: 'G' },
]

export default function Layout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="icon" style={{ background: '#0f6b57', color: '#fff' }}>SN</span>
          <div>
            StudyNest
            <small>Student tools in one app</small>
          </div>
        </div>
        <nav className="nav">
          {links.map((link) => (
            <NavLink key={link.to} to={link.to} end={link.to === '/'}>
              <span className="icon" style={{ width: 28, height: 28, fontSize: 13, background: '#efe7d4' }}>{link.icon}</span>
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div style={{ marginTop: 'auto' }}>
          <p className="muted">{user?.fullName}</p>
          <button
            className="btn ghost"
            onClick={() => {
              logout()
              navigate('/login')
            }}
          >
            Log out
          </button>
        </div>
      </aside>
      <main className="main">
        <Outlet />
      </main>
    </div>
  )
}
