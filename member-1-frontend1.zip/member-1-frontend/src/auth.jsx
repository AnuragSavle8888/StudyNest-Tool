import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { authApi, setToken, settingsApi } from './api.js'

const AuthContext = createContext(null)

const WALLPAPERS = [
  { id: 'aurora', label: 'Aurora desk', url: 'linear-gradient(135deg, #123c4a 0%, #2d6a4f 42%, #95d5b2 100%)' },
  { id: 'dusk', label: 'Library dusk', url: 'linear-gradient(135deg, #1d3557 0%, #457b9d 48%, #e63946 100%)' },
  { id: 'mint', label: 'Campus mint', url: 'linear-gradient(135deg, #14213d 0%, #2a9d8f 55%, #e9c46a 100%)' },
  { id: 'ink', label: 'Night ink', url: 'linear-gradient(135deg, #0b132b 0%, #1c2541 40%, #5bc0be 100%)' },
]

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [settings, setSettings] = useState({
    theme: 'light',
    revisionMode: false,
    wallpaper: 'aurora',
    wallpaperPhoto: '',
  })
  const [loading, setLoading] = useState(true)

  async function refresh() {
    try {
      const me = await authApi.me()
      setUser(me)
      const next = await settingsApi.get()
      setSettings(next)
    } catch {
      setUser(null)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme || 'light'
    document.documentElement.dataset.revision = settings.revisionMode ? 'on' : 'off'
  }, [settings])

  const value = useMemo(
    () => ({
      user,
      settings,
      wallpapers: WALLPAPERS,
      loading,
      async login(payload) {
        const data = await authApi.login(payload)
        setToken(data.token)
        await refresh()
      },
      async signup(payload) {
        const data = await authApi.signup(payload)
        setToken(data.token)
        await refresh()
      },
      logout() {
        setToken(null)
        setUser(null)
      },
      async updateSettings(patch) {
        const next = await settingsApi.save({ ...settings, ...patch })
        setSettings(next)
      },
    }),
    [user, settings, loading],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}

export { WALLPAPERS }
