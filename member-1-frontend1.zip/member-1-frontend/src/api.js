const TOKEN_KEY = 'studynest.token'

export function getToken() {
  return localStorage.getItem(TOKEN_KEY)
}

export function setToken(token) {
  if (token) localStorage.setItem(TOKEN_KEY, token)
  else localStorage.removeItem(TOKEN_KEY)
}

export async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) }
  const token = getToken()
  if (token) headers.Authorization = `Bearer ${token}`
  if (!(options.body instanceof FormData) && options.body && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json'
  }
  const response = await fetch(`/api${path}`, { ...options, headers })
  const text = await response.text()
  let data = null
  try {
    data = text ? JSON.parse(text) : null
  } catch {
    data = { message: text }
  }
  if (!response.ok) {
    const message = data?.message || data?.error || `Request failed (${response.status})`
    throw new Error(message)
  }
  return data
}

export const authApi = {
  signup: (body) => api('/auth/signup', { method: 'POST', body: JSON.stringify(body) }),
  login: (body) => api('/auth/login', { method: 'POST', body: JSON.stringify(body) }),
  me: () => api('/auth/me'),
}

export const settingsApi = {
  get: () => api('/settings'),
  save: (body) => api('/settings', { method: 'PUT', body: JSON.stringify(body) }),
}

export const summaryApi = {
  list: () => api('/summaries'),
  create: (body) => api('/summaries', { method: 'POST', body: JSON.stringify(body) }),
  upload: (form) => api('/summaries/upload', { method: 'POST', body: form }),
}

export const quizApi = {
  list: () => api('/quizzes'),
  create: (body) => api('/quizzes', { method: 'POST', body: JSON.stringify(body) }),
  get: (id) => api(`/quizzes/${id}`),
  attempt: (id, body) => api(`/quizzes/${id}/attempt`, { method: 'POST', body: JSON.stringify(body) }),
  results: (id) => api(`/quizzes/${id}/results`),
}

export const toolApi = {
  flashcards: (body) => api('/flashcards', { method: 'POST', body: JSON.stringify(body) }),
  bullets: (body) => api('/bullets', { method: 'POST', body: JSON.stringify(body) }),
  maths: (body) => api('/maths', { method: 'POST', body: JSON.stringify(body) }),
}

export const reminderApi = {
  list: () => api('/reminders'),
  create: (body) => api('/reminders', { method: 'POST', body: JSON.stringify(body) }),
  toggle: (id) => api(`/reminders/${id}/toggle`, { method: 'POST' }),
}

export const reportApi = {
  weekly: () => api('/reports/weekly'),
  monthly: () => api('/reports/monthly'),
}

export const taskApi = {
  list: () => api('/tasks'),
  complete: (id) => api(`/tasks/${id}/complete`, { method: 'POST' }),
}

export const historyApi = {
  list: () => api('/history'),
}
