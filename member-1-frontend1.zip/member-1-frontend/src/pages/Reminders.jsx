import { useEffect, useState } from 'react'
import { reminderApi } from '../api.js'

export default function Reminders() {
  const [items, setItems] = useState([])
  const [form, setForm] = useState({ title: 'Revise OS notes', time: '19:00', seconds: 25 * 60 })
  const [left, setLeft] = useState(0)
  const [running, setRunning] = useState(false)

  async function load() {
    setItems(await reminderApi.list())
  }

  useEffect(() => {
    load()
  }, [])

  useEffect(() => {
    if (!running || left <= 0) return undefined
    const timer = setInterval(() => {
      setLeft((value) => {
        if (value <= 1) {
          setRunning(false)
          window.alert('StudyNest reminder: time to revise.')
          return 0
        }
        return value - 1
      })
    }, 1000)
    return () => clearInterval(timer)
  }, [running, left])

  async function create(event) {
    event.preventDefault()
    await reminderApi.create(form)
    await load()
  }

  const mm = String(Math.floor(left / 60)).padStart(2, '0')
  const ss = String(left % 60).padStart(2, '0')

  return (
    <div className="panel">
      <h1>Daily reminder alarm</h1>
      <div className="card">
        <div className="timer">{mm}:{ss}</div>
        <div className="row">
          <button className="btn" onClick={() => { setLeft(Number(form.seconds)); setRunning(true) }}>Start timer</button>
          <button className="btn ghost" onClick={() => setRunning(false)}>Pause</button>
        </div>
      </div>
      <form onSubmit={create}>
        <label>Reminder title</label>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <label>Alarm time</label>
        <input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} />
        <button className="btn amber" type="submit">Save reminder</button>
      </form>
      {items.map((item) => (
        <article key={item.id} className="card" style={{ marginTop: 10 }}>
          <strong>{item.title}</strong>
          <p className="muted">Alarm at {item.time}</p>
        </article>
      ))}
    </div>
  )
}
