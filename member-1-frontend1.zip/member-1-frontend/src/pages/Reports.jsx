import { useEffect, useState } from 'react'
import { reportApi } from '../api.js'

export default function Reports() {
  const [weekly, setWeekly] = useState(null)
  const [monthly, setMonthly] = useState(null)

  useEffect(() => {
    reportApi.weekly().then(setWeekly)
    reportApi.monthly().then(setMonthly)
  }, [])

  return (
    <div className="grid">
      <section className="panel">
        <h1>Weekly report</h1>
        <p>Summaries: {weekly?.summaries ?? 0}</p>
        <p>Quizzes: {weekly?.quizzes ?? 0}</p>
        <p>Tasks completed: {weekly?.tasksCompleted ?? 0}</p>
        <p>Points earned: {weekly?.points ?? 0}</p>
      </section>
      <section className="panel">
        <h1>Monthly report</h1>
        <p>Summaries: {monthly?.summaries ?? 0}</p>
        <p>Quizzes: {monthly?.quizzes ?? 0}</p>
        <p>Tasks completed: {monthly?.tasksCompleted ?? 0}</p>
        <p>Points earned: {monthly?.points ?? 0}</p>
      </section>
    </div>
  )
}
