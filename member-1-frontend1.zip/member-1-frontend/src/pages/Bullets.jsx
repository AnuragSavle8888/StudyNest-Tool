import { useState } from 'react'
import { toolApi } from '../api.js'

export default function Bullets() {
  const [text, setText] = useState('')
  const [bullets, setBullets] = useState([])

  async function convert(event) {
    event.preventDefault()
    const data = await toolApi.bullets({ sourceText: text })
    setBullets(data.bullets || [])
  }

  return (
    <div className="panel">
      <h1>Paragraph to bullet points</h1>
      <form onSubmit={convert}>
        <textarea rows={8} value={text} onChange={(e) => setText(e.target.value)} required />
        <button className="btn" type="submit">Make bullets</button>
      </form>
      <ul>
        {bullets.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  )
}
