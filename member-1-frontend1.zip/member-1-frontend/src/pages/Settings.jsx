import { useAuth } from '../auth.jsx'

export default function Settings() {
  const { settings, updateSettings, wallpapers } = useAuth()

  function onPhoto(event) {
    const file = event.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => updateSettings({ wallpaperPhoto: reader.result })
    reader.readAsDataURL(file)
  }

  return (
    <div className="panel">
      <h1>Settings</h1>
      <label className="choice">
        <input
          type="checkbox"
          checked={settings.revisionMode}
          onChange={(e) => updateSettings({ revisionMode: e.target.checked })}
        />
        Revision mode (calmer colours, fewer distractions)
      </label>
      <h3>Theme</h3>
      <div className="row">
        <button className="btn" onClick={() => updateSettings({ theme: 'light' })}>Light mode</button>
        <button className="btn ghost" onClick={() => updateSettings({ theme: 'dark' })}>Dark mode</button>
      </div>
      <h3>Wallpaper</h3>
      <div className="grid">
        {wallpapers.map((item) => (
          <button
            key={item.id}
            className="card"
            style={{ backgroundImage: item.url, color: '#fff', minHeight: 90 }}
            onClick={() => updateSettings({ wallpaper: item.id, wallpaperPhoto: '' })}
          >
            {item.label}
          </button>
        ))}
      </div>
      <label>Upload a photo wallpaper</label>
      <input type="file" accept="image/*" onChange={onPhoto} />
    </div>
  )
}
