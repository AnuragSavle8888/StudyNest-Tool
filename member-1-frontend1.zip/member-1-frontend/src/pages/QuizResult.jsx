import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { quizApi } from '../api.js'

export default function QuizResult() {
  const { id } = useParams()
  const [data, setData] = useState(null)

  useEffect(() => {
    quizApi.results(id).then(setData)
  }, [id])

  if (!data) return <p>Loading result...</p>
  const latest = data.attempts?.[0]

  return (
    <div className="panel">
      <h1>Quiz result</h1>
      <p>Attempts: {data.attemptCount}</p>
      {latest && (
        <div className="card">
          <p>Score: {latest.score} / {latest.total}</p>
          <p>Time taken: {latest.durationSeconds} seconds</p>
          <p>Submitted: {new Date(latest.createdAt).toLocaleString()}</p>
        </div>
      )}
      <table>
        <thead>
          <tr>
            <th>Attempt</th>
            <th>Score</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {data.attempts.map((item, index) => (
            <tr key={item.id}>
              <td>{data.attempts.length - index}</td>
              <td>{item.score} / {item.total}</td>
              <td>{item.durationSeconds}s</td>
            </tr>
          ))}
        </tbody>
      </table>
      <Link className="btn ghost" to="/quiz">Back to quizzes</Link>
    </div>
  )
}
