import { useEffect, useState } from 'react'
import { historyApi } from '../api.js'

export default function History() {
  const [items, setItems] = useState([])

  useEffect(() => {
    historyApi.list().then(setItems)
  }, [])

  return (
    <div className="panel">
      <h1>User history</h1>
      <table>
        <thead>
          <tr>
            <th>When</th>
            <th>Action</th>
            <th>Detail</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id}>
              <td>{new Date(item.createdAt).toLocaleString()}</td>
              <td>{item.action}</td>
              <td>{item.detail}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
