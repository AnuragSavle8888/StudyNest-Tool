import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { quizApi } from '../api.js'

export default function QuizAttempt() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [quiz, setQuiz] = useState(null)
  const [answers, setAnswers] = useState({})
  const [started] = useState(Date.now())
  const [error, setError] = useState('')

  useEffect(() => {
    quizApi.get(id).then(setQuiz).catch((err) => setError(err.message))
  }, [id])

  async function submit(event) {
    event.preventDefault()
    try {
      await quizApi.attempt(id, {
        answers,
        durationSeconds: Math.max(1, Math.round((Date.now() - started) / 1000)),
      })
      navigate(`/quiz/${id}/result`)
    } catch (err) {
      setError(err.message)
    }
  }

  if (!quiz) return <p>{error || 'Loading quiz...'}</p>

  return (
    <form className="panel" onSubmit={submit}>
      <h1>{quiz.title}</h1>
      {quiz.questions.map((q, index) => (
        <fieldset key={q.id} className="card" style={{ marginBottom: 12 }}>
          <legend>{index + 1}. {q.prompt}</legend>
          {['A', 'B', 'C', 'D'].map((letter) => (
            <label key={letter} className="choice">
              <input
                type="radio"
                name={`q-${q.id}`}
                value={letter}
                onChange={() => setAnswers({ ...answers, [q.id]: letter })}
                required
              />
              {letter}) {q[`option${letter}`]}
            </label>
          ))}
        </fieldset>
      ))}
      {error && <p className="error">{error}</p>}
      <button className="btn" type="submit">Submit answers</button>
    </form>
  )
}
