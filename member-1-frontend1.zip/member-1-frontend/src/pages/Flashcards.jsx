import { useState } from 'react'
import { toolApi } from '../api.js'

export default function Flashcards() {
  const [text, setText] = useState('')
  const [cards, setCards] = useState([])
  const [flip, setFlip] = useState({})

  async function generate(event) {
    event.preventDefault()
    const data = await toolApi.flashcards({ sourceText: text })
    setCards(data.cards || [])
    setFlip({})
  }

  return (
    <div className="panel">
      <h1>Flash card generator</h1>
      <form onSubmit={generate}>
        <textarea rows={8} value={text} onChange={(e) => setText(e.target.value)} placeholder="Paste a topic or notes" required />
        <button className="btn" type="submit">Create cards</button>
      </form>
      <div className="grid">
        {cards.map((card, index) => (
          <button
            key={index}
            className="card flash"
            onClick={() => setFlip({ ...flip, [index]: !flip[index] })}
          >
            <strong>{flip[index] ? card.back : card.front}</strong>
            <small className="muted">{flip[index] ? 'Answer' : 'Question'} - tap to flip</small>
          </button>
        ))}
      </div>
    </div>
  )
}
