import { Link } from 'react-router-dom'
import { useAuth } from '../auth.jsx'

const tools = [
  { to: '/summariser', title: 'Summariser', text: '500-word notes from PDF, TXT or ZIP', icon: 'S', color: '#0f6b57' },
  { to: '/quiz', title: 'Quiz generator', text: 'Up to 20 MCQs with A B C D', icon: 'Q', color: '#d97706' },
  { to: '/flashcards', title: 'Flash cards', text: 'Turn notes into flip cards', icon: 'F', color: '#1d4ed8' },
  { to: '/bullets', title: 'Bullet points', text: 'Paragraph to clean bullets', icon: 'B', color: '#7c3aed' },
  { to: '/maths', title: 'Maths diagrams', text: 'Algebra and geometry from text', icon: 'M', color: '#be123c' },
  { to: '/reminders', title: 'Daily reminder', text: 'Timer alarm for revision', icon: 'R', color: '#0e7490' },
]

export default function Dashboard() {
  const { user, settings, wallpapers } = useAuth()
  const wallpaper = wallpapers.find((item) => item.id === settings.wallpaper) || wallpapers[0]
  const background = settings.wallpaperPhoto
    ? `linear-gradient(180deg, rgba(12,18,24,0.15), rgba(12,18,24,0.72)), url(${settings.wallpaperPhoto})`
    : wallpaper.url

  return (
    <div>
      <section className="hero" style={{ backgroundImage: background }}>
        <span className="badge">Student workspace</span>
        <h1>{user?.fullName}</h1>
        <p>All the tools you need to learn faster, in one application.</p>
      </section>
      <div className="grid">
        {tools.map((tool) => (
          <Link key={tool.to} to={tool.to} className="card tool-card">
            <span className="icon" style={{ background: tool.color, color: '#fff' }}>{tool.icon}</span>
            <div>
              <h3>{tool.title}</h3>
              <p className="muted">{tool.text}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
