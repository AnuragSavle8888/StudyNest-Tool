import { useEffect, useState } from 'react'
import { summaryApi } from '../api.js'

const LIMIT = 500

export default function Summariser() {
  const [text, setText] = useState('')
  const [title, setTitle] = useState('Lecture notes')
  const [result, setResult] = useState('')
  const [items, setItems] = useState([])
  const [error, setError] = useState('')
  const words = text.trim() ? text.trim().split(/\s+/).length : 0

  async function load() {
    setItems(await summaryApi.list())
  }

  useEffect(() => {
    load().catch((err) => setError(err.message))
  }, [])

  async function generate(event) {
    event.preventDefault()
    setError('')
    if (words > LIMIT) {
      setError(`Keep notes under ${LIMIT} words.`)
      return
    }
    const data = await summaryApi.create({ title, content: text })
    setResult(data.summaryText)
    await load()
  }

  async function onFile(event) {
    const file = event.target.files?.[0]
    if (!file) return
    const form = new FormData()
    form.append('file', file)
    form.append('title', title || file.name)
    try {
      const data = await summaryApi.upload(form)
      setText(data.sourceText || '')
      setResult(data.summaryText || '')
      await load()
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="panel">
      <h1>Student summariser</h1>
      <p className="muted">Paste notes or upload a PDF, TXT or ZIP. Limit {LIMIT} words.</p>
      <form onSubmit={generate}>
        <label>Title</label>
        <input value={title} onChange={(e) => setTitle(e.target.value)} />
        <label>Notes ({words}/{LIMIT} words)</label>
        <textarea rows={10} value={text} onChange={(e) => setText(e.target.value)} />
        <input type="file" accept=".pdf,.txt,.zip,application/pdf,text/plain,application/zip" onChange={onFile} />
        {error && <p className="error">{error}</p>}
        <button className="btn" type="submit">Generate summary</button>
      </form>
      {result && (
        <div className="card" style={{ marginTop: 16 }}>
          <h3>Summary</h3>
          <p>{result}</p>
        </div>
      )}
      <h3>Saved summaries</h3>
      {items.map((item) => (
        <article key={item.id} className="card" style={{ marginTop: 10 }}>
          <strong>{item.title}</strong>
          <p className="muted">{item.summaryText}</p>
        </article>
      ))}
    </div>
  )
}
