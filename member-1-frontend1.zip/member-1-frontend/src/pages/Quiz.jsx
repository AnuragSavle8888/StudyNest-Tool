import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { quizApi } from '../api.js'

export default function Quiz() {
  const [source, setSource] = useState('')
  const [count, setCount] = useState(10)
  const [items, setItems] = useState([])
  const [error, setError] = useState('')

  async function load() {
    setItems(await quizApi.list())
  }

  useEffect(() => {
    load().catch((err) => setError(err.message))
  }, [])

  async function create(event) {
    event.preventDefault()
    setError('')
    try {
      await quizApi.create({ sourceText: source, questionCount: Number(count) })
      setSource('')
      await load()
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="panel">
      <h1>Quiz generator</h1>
      <p className="muted">Create up to 20 multiple-choice questions with options A, B, C and D.</p>
      <form onSubmit={create}>
        <label>Study text</label>
        <textarea rows={8} value={source} onChange={(e) => setSource(e.target.value)} required />
        <label>Number of questions</label>
        <select value={count} onChange={(e) => setCount(e.target.value)}>
          {[5, 10, 15, 20].map((n) => (
            <option key={n} value={n}>{n}</option>
          ))}
        </select>
        {error && <p className="error">{error}</p>}
        <button className="btn" type="submit">Generate quiz</button>
      </form>
      <div className="grid">
        {items.map((quiz) => (
          <Link key={quiz.id} to={`/quiz/${quiz.id}`} className="card">
            <h3>{quiz.title}</h3>
            <p className="muted">{quiz.questionCount} questions</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
