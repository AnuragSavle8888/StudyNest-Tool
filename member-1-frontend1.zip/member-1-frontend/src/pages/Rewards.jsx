import { useEffect, useState } from 'react'
import { taskApi } from '../api.js'

export default function Rewards() {
  const [data, setData] = useState({ points: 0, tasks: [] })

  async function load() {
    setData(await taskApi.list())
  }

  useEffect(() => {
    load()
  }, [])

  async function complete(id) {
    await taskApi.complete(id)
    await load()
  }

  return (
    <div className="panel">
      <h1>Daily task rewards</h1>
      <p>Total points: <strong>{data.points}</strong></p>
      {data.tasks.map((task) => (
        <article key={task.id} className="card" style={{ marginTop: 10 }}>
          <strong>{task.title}</strong>
          <p className="muted">+{task.points} points</p>
          {task.completed ? (
            <span className="ok">Completed</span>
          ) : (
            <button className="btn" onClick={() => complete(task.id)}>Mark complete</button>
          )}
        </article>
      ))}
    </div>
  )
}
