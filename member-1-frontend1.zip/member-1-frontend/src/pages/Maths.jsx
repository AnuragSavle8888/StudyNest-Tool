import { useState } from 'react'
import { toolApi } from '../api.js'

export default function Maths() {
  const [text, setText] = useState('Draw a right triangle with sides 3, 4 and 5')
  const [kind, setKind] = useState('geometry')
  const [svg, setSvg] = useState('')

  async function draw(event) {
    event.preventDefault()
    const data = await toolApi.maths({ sourceText: text, kind })
    setSvg(data.svg || '')
  }

  return (
    <div className="panel">
      <h1>Maths text to diagram</h1>
      <form onSubmit={draw}>
        <label>Type</label>
        <select value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="geometry">Geometry</option>
          <option value="algebra">Algebra</option>
        </select>
        <textarea rows={5} value={text} onChange={(e) => setText(e.target.value)} required />
        <button className="btn" type="submit">Draw diagram</button>
      </form>
      {svg && <div className="math-svg card" dangerouslySetInnerHTML={{ __html: svg }} />}
    </div>
  )
}
